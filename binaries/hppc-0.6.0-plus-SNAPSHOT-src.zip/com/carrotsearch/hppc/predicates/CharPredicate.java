package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>char</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: CharPredicate.java") 
public interface CharPredicate
{
    public boolean apply(char value);
}
