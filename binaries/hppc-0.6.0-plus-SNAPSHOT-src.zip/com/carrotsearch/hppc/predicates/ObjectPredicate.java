package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>KType</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ObjectPredicate.java") 
public interface ObjectPredicate<KType>
{
    public boolean apply(KType value);
}
