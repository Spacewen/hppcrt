package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>byte</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: BytePredicate.java") 
public interface BytePredicate
{
    public boolean apply(byte value);
}
