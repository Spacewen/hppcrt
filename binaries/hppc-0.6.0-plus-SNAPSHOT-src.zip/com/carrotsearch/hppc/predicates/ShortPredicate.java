package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>short</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ShortPredicate.java") 
public interface ShortPredicate
{
    public boolean apply(short value);
}
