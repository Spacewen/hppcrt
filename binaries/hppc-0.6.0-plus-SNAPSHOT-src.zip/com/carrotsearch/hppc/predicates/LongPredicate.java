package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>long</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: LongPredicate.java") 
public interface LongPredicate
{
    public boolean apply(long value);
}
