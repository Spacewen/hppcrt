package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>double</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: DoublePredicate.java") 
public interface DoublePredicate
{
    public boolean apply(double value);
}
