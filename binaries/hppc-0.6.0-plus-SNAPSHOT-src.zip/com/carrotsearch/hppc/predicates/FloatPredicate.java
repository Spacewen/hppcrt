package com.carrotsearch.hppc.predicates;

/**
 * A predicate that applies to <code>float</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: FloatPredicate.java") 
public interface FloatPredicate
{
    public boolean apply(float value);
}
