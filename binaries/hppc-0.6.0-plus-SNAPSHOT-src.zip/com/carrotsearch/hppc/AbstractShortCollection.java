package com.carrotsearch.hppc;

import java.util.Arrays;

import com.carrotsearch.hppc.cursors.ShortCursor;
import com.carrotsearch.hppc.predicates.ShortPredicate;

/**
 * Common superclass for collections.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: AbstractShortCollection.java") 
abstract class AbstractShortCollection implements ShortCollection
{
    /**
     * Default implementation uses a predicate for removal.
     */
    /*  */
    @Override
    public int removeAll(final ShortLookupContainer c)
    {
        // We know c holds sub-types of short and we're not modifying c, so go unchecked.
        final ShortContainer c2 = (ShortContainer) c;
        return this.removeAll(new ShortPredicate()
                {
            public boolean apply(short k)
            {
                return c2.contains(k);
            }
                });
    }

    /**
     * Default implementation uses a predicate for retaining.
     */
    /*  */
    @Override
    public int retainAll(final ShortLookupContainer c)
    {
        // We know c holds sub-types of short and we're not modifying c, so go unchecked.
        final ShortContainer c2 = (ShortContainer) c;
        return this.removeAll(new ShortPredicate()
                {
            public boolean apply(short k)
            {
                return !c2.contains(k);
            }
                });
    }

    /**
     * Default implementation redirects to {@link #removeAll(ShortPredicate)}
     * and negates the predicate.
     */
    @Override
    public int retainAll(final ShortPredicate predicate)
    {
        return removeAll(new ShortPredicate()
                {
            public boolean apply(short value)
            {
                return !predicate.apply(value);
            };
                });
    }

    /**
     * Default implementation of copying to a new array.
     */
    @Override
        public short [] toArray()
        
    {
        final int size = size();

        final short [] array =
                                new short [size];
                 

        return toArray(array);
    }

    /**
     * Default implementation of copying to an existing array.
     */
    @Override
    public short[] toArray(short[] target)
    {
        assert target.length >= size() : "Target array must be >= " + size();

        int i = 0;

        //use default iterator capability
        for (ShortCursor c : this)
        {
            target[i++] = c.value;
        }

        return target;
    }

    /*  */


    /**
     * Convert the contents of this container to a human-friendly string.
     */
    @Override
    public String toString()
    {
        return Arrays.toString(this.toArray());
    }
}
