package com.carrotsearch.hppc;

import java.util.Arrays;

import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.predicates.LongPredicate;

/**
 * Common superclass for collections.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: AbstractLongCollection.java") 
abstract class AbstractLongCollection implements LongCollection
{
    /**
     * Default implementation uses a predicate for removal.
     */
    /*  */
    @Override
    public int removeAll(final LongLookupContainer c)
    {
        // We know c holds sub-types of long and we're not modifying c, so go unchecked.
        final LongContainer c2 = (LongContainer) c;
        return this.removeAll(new LongPredicate()
                {
            public boolean apply(long k)
            {
                return c2.contains(k);
            }
                });
    }

    /**
     * Default implementation uses a predicate for retaining.
     */
    /*  */
    @Override
    public int retainAll(final LongLookupContainer c)
    {
        // We know c holds sub-types of long and we're not modifying c, so go unchecked.
        final LongContainer c2 = (LongContainer) c;
        return this.removeAll(new LongPredicate()
                {
            public boolean apply(long k)
            {
                return !c2.contains(k);
            }
                });
    }

    /**
     * Default implementation redirects to {@link #removeAll(LongPredicate)}
     * and negates the predicate.
     */
    @Override
    public int retainAll(final LongPredicate predicate)
    {
        return removeAll(new LongPredicate()
                {
            public boolean apply(long value)
            {
                return !predicate.apply(value);
            };
                });
    }

    /**
     * Default implementation of copying to a new array.
     */
    @Override
        public long [] toArray()
        
    {
        final int size = size();

        final long [] array =
                                new long [size];
                 

        return toArray(array);
    }

    /**
     * Default implementation of copying to an existing array.
     */
    @Override
    public long[] toArray(long[] target)
    {
        assert target.length >= size() : "Target array must be >= " + size();

        int i = 0;

        //use default iterator capability
        for (LongCursor c : this)
        {
            target[i++] = c.value;
        }

        return target;
    }

    /*  */


    /**
     * Convert the contents of this container to a human-friendly string.
     */
    @Override
    public String toString()
    {
        return Arrays.toString(this.toArray());
    }
}
