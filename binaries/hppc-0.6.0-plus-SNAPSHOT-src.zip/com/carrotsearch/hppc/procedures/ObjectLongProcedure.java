package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>KType</code>, <code>long</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ObjectLongProcedure.java") 
public interface ObjectLongProcedure<KType>
{
    public void apply(KType key, long value);
}
