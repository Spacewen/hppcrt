package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>float</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: FloatProcedure.java") 
public interface FloatProcedure
{
    public void apply(float value);
}
