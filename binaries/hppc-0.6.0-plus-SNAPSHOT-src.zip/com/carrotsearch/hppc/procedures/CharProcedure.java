package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>char</code> objects.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: CharProcedure.java") 
public interface CharProcedure
{
    public void apply(char value);
}
