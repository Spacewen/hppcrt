package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>long</code>, <code>double</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: LongDoubleProcedure.java") 
public interface LongDoubleProcedure
{
    public void apply(long key, double value);
}
