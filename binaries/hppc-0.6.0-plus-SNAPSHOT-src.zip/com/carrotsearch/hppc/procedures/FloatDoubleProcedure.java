package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>float</code>, <code>double</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: FloatDoubleProcedure.java") 
public interface FloatDoubleProcedure
{
    public void apply(float key, double value);
}
