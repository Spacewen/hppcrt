package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>char</code>, <code>double</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: CharDoubleProcedure.java") 
public interface CharDoubleProcedure
{
    public void apply(char key, double value);
}
