package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>short</code>, <code>byte</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ShortByteProcedure.java") 
public interface ShortByteProcedure
{
    public void apply(short key, byte value);
}
