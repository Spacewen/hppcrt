package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>double</code>, <code>short</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: DoubleShortProcedure.java") 
public interface DoubleShortProcedure
{
    public void apply(double key, short value);
}
