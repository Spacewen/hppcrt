package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>long</code>, <code>int</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: LongIntProcedure.java") 
public interface LongIntProcedure
{
    public void apply(long key, int value);
}
