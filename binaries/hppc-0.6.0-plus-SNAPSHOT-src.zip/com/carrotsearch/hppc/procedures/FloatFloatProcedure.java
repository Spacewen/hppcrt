package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>float</code>, <code>float</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: FloatFloatProcedure.java") 
public interface FloatFloatProcedure
{
    public void apply(float key, float value);
}
