package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>KType</code>, <code>float</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ObjectFloatProcedure.java") 
public interface ObjectFloatProcedure<KType>
{
    public void apply(KType key, float value);
}
