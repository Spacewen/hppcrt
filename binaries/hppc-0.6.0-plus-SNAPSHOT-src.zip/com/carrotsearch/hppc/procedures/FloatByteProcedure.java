package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>float</code>, <code>byte</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: FloatByteProcedure.java") 
public interface FloatByteProcedure
{
    public void apply(float key, byte value);
}
