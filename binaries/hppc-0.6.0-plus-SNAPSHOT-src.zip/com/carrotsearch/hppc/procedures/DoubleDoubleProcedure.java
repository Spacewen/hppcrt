package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>double</code>, <code>double</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: DoubleDoubleProcedure.java") 
public interface DoubleDoubleProcedure
{
    public void apply(double key, double value);
}
