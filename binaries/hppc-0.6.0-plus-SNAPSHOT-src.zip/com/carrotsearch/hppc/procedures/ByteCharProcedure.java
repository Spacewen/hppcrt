package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>byte</code>, <code>char</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ByteCharProcedure.java") 
public interface ByteCharProcedure
{
    public void apply(byte key, char value);
}
