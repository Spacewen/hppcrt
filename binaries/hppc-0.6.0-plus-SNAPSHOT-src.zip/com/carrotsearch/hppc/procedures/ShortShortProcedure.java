package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>short</code>, <code>short</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ShortShortProcedure.java") 
public interface ShortShortProcedure
{
    public void apply(short key, short value);
}
