package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>long</code>, <code>byte</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: LongByteProcedure.java") 
public interface LongByteProcedure
{
    public void apply(long key, byte value);
}
