package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>long</code>, <code>char</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: LongCharProcedure.java") 
public interface LongCharProcedure
{
    public void apply(long key, char value);
}
