package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>KType</code>, <code>int</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ObjectIntProcedure.java") 
public interface ObjectIntProcedure<KType>
{
    public void apply(KType key, int value);
}
