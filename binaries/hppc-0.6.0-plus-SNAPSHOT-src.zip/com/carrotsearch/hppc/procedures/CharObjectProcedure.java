package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>char</code>, <code>VType</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: CharObjectProcedure.java") 
public interface CharObjectProcedure<VType>
{
    public void apply(char key, VType value);
}
