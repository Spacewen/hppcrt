package com.carrotsearch.hppc.procedures;

/**
 * A procedure that applies to <code>byte</code>, <code>double</code> pairs.
 */
 @javax.annotation.Generated(date = "2013-08-20T21:23:37+0200", value = "HPPC generated from: ByteDoubleProcedure.java") 
public interface ByteDoubleProcedure
{
    public void apply(byte key, double value);
}
